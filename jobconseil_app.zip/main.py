
import streamlit as st

# Navigation simple
st.sidebar.title("JobConseil")
page = st.sidebar.radio("Menu", ["Accueil", "Assistant IA", "Créer un CV", "Lettre de motivation", "Offres d'emploi", "Mon compte"])

if page == "Accueil":
    st.title("Bienvenue sur JobConseil")
    st.write("Votre assistant pour le droit du travail, la création de CV, et la recherche d'emploi.")
    
    st.subheader("Nos offres")
    st.markdown("""
    | Fonctionnalité                                | Gratuit (GPT-3.5) | Premium (GPT-4 Turbo) |
    |----------------------------------------------|:-----------------:|:---------------------:|
    | Assistant IA (droit, CV, lettres…)            | ✅                | ✅                   |
    | Générateur de CV / lettres                    | ✅                | ✅                   |
    | Historique des conversations                  | ❌                | ✅                   |
    | Priorité de réponse / support dédié           | ❌                | ✅                   |
    | Accès GPT-4 Turbo                             | ❌                | ✅                   |
    | **Prix mensuel**                              | **0 €**           | **9,99 €**            |
    """)
    
elif page == "Assistant IA":
    st.title("Assistant IA - JobConseil")
    question = st.text_area("Posez votre question :")
    if st.button("Obtenir une réponse"):
        st.info("Réponse simulée (IA en cours de configuration).")
        
elif page == "Créer un CV":
    st.title("Générateur de CV")
    st.info("Fonctionnalité à venir.")
    
elif page == "Lettre de motivation":
    st.title("Générateur de lettre de motivation")
    st.info("Fonctionnalité à venir.")
    
elif page == "Offres d'emploi":
    st.title("Offres d'emploi")
    st.info("Connexion à l'API Pôle Emploi en cours.")
    
elif page == "Mon compte":
    st.title("Mon compte")
    st.info("Système de connexion à venir.")
